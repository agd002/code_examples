
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "calculations.h"
#include "competition.h"

float inch_converter(int feet, float inches)
{
    float conv = feet*12;
    float total = conv + inches;
    return total;
}

float total(competitor_nptr temp_ptr)
{
    float cucu, carr, bean, total;
    cucu = temp_ptr->competitor_cucumber;
    carr = temp_ptr->competitor_carrot;
    bean = temp_ptr->competitor_bean;
    
    total = (cucu + carr + bean);
    return total;
}

int get_int(float change)
{
    int new_int;
    new_int =  (int)change/12;
    
    return new_int;
}
float get_float(float change)
{
    float new_float;
    new_float = fmod(change, 12);
    
    return new_float;
}