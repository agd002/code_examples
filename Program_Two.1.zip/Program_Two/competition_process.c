/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <stdio.h>
#include <stdlib.h>
#include "competition.h"
#include "calculations.h"

void add_to_tree(competitor_nptr add_to, competitor_nptr to_add, float score_len_add_to, float score_len_to_add)
{
    
    if (score_len_add_to <= score_len_to_add)
    {
        if (add_to -> right == NULL)
        {
            add_to -> right = to_add;

        } else {
            score_len_add_to = total(add_to -> right);
            add_to_tree(add_to -> right, to_add, score_len_add_to, score_len_to_add);
        }
    } else {
        if (add_to -> left == NULL) 
        {
            add_to -> left = to_add;

        } else {
            score_len_add_to = total(add_to -> left);
            add_to_tree(add_to -> left, to_add, score_len_add_to, score_len_to_add);
        }
}
    
}
 
competitor_nptr read_create_tree(FILE * temp_file_ptr)
{
    competitor_node * temp_node;
    int * cont_scan;
    int comp_num = 1;
    competitor_nptr root_to_return;
    char competitor_name[MAX_READ_LEN];
    char competitor_addr[MAX_READ_LEN];
    char competitor_phone[MAX_READ_LEN];
    float prod_len[3];
    
    while(!feof(temp_file_ptr))
    {
        /*read in node*/
        if(cont_scan != NULL)
        {
            temp_node = malloc(sizeof(competitor_node));
            fgets(competitor_name, MAX_READ_LEN, temp_file_ptr);
            fgets(competitor_addr, MAX_READ_LEN, temp_file_ptr);
            fgets(competitor_phone, MAX_READ_LEN, temp_file_ptr);

            int i = 0;
            int feet;
            float inches;
            float insert;
            for(i = 0; i<2 ; i++)
            {
                fscanf(temp_file_ptr, "%d %f \n", &feet, &inches);
                prod_len[i] = inch_converter(feet, inches);
                insert = prod_len[i];    
            }
            fscanf(temp_file_ptr, "%d %f \n", &feet, &inches);
            prod_len[2] = inch_converter(feet, inches);
            insert = prod_len[2];
            
            strcpy(temp_node->competitor_name, competitor_name);
            strcpy(temp_node->competitor_address, competitor_addr);
            strcpy(temp_node->competitor_contact_details, competitor_phone);
            temp_node->competitor_num = comp_num;
            temp_node->competitor_cucumber = prod_len[0];
            temp_node->competitor_carrot = prod_len[1];
            temp_node->competitor_bean = prod_len[2];
            
            if(comp_num == 1){root_to_return = temp_node;}
            /*add node to tree*/
            float score_len_add_to = total(root_to_return);
            float score_len_to_add = total(temp_node);
            if(comp_num >1)add_to_tree(root_to_return, temp_node, score_len_add_to, score_len_to_add);
            /* if this is the first competitor, make them the root to return
             * and increment int comp_num by one.   
             */
           comp_num++;
        }
       
    }
    
    return root_to_return;
}

competitor_nptr create_leader_board(char * data_file_path)
{
    char comp_name[MAX_READ_LEN]; 
    char comp_date[MAX_READ_LEN];
    competitor_nptr root_ptr;
    
    FILE * file_ptr;
    
    file_ptr = fopen(data_file_path, "r");
    
    if(file_ptr != NULL)
    {   
        fgets(comp_name, MAX_READ_LEN, file_ptr);
        //strtok(comp_name, "\n");
        fgets(comp_date, MAX_READ_LEN, file_ptr);
        root_ptr = read_create_tree(file_ptr);
        return root_ptr;
    }
    fclose(file_ptr);
        
    
}
competition_nptr create_event_details_struct(char * data_file_path)
{
    competition_nptr root;
    char comp_name[MAX_READ_LEN]; 
    char comp_date[MAX_READ_LEN];
    FILE * file_ptr;
    competition_node * temp_node;
    temp_node = malloc(sizeof(competitor_node));
    file_ptr = fopen(data_file_path, "r");
    
    if(file_ptr != NULL)
    {   
        fgets(comp_name, MAX_READ_LEN, file_ptr);
        strtok(comp_name, "\n");
        fgets(comp_date, MAX_READ_LEN, file_ptr);
        strcpy(temp_node->competition_name, comp_name);
        strcpy(temp_node->competition_date, comp_date);
    } 
    
    root = temp_node;
    return root;
    fclose(file_ptr);
}