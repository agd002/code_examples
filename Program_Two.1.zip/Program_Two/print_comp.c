/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "competition.h"
#include "calculations.h"

void print_competitors(competitor_nptr root_ptr)
{
    /* transform floats to integer and using fmod()*/
    int int_vals[4];
    float f_vals[4];
    float a1, a2, a3;
    float parser[3];
    
    int i;
    a1 = root_ptr->competitor_cucumber; a2 = root_ptr->competitor_carrot; a3 = root_ptr->competitor_bean;
    parser[0] = a1;
    parser[1] = a2;
    parser[2] = a3;  
        
    for(i=0; i<3; i++)
    {
        int_vals[i] = get_int(parser[i]);
        f_vals[i] = get_float(parser[i]);
    }
    float check = total(root_ptr);
    int_vals[3] = get_int(check);
    f_vals[3] = get_float(check);
    int len_max = 3;
    strtok(root_ptr->competitor_name, "\n");
    printf("%-18s", root_ptr->competitor_name);
    printf("%2d", root_ptr->competitor_num);
    printf("%13dft", int_vals[0]); printf("%5.1fin", f_vals[0]);
    printf("%5dft", int_vals[1]); printf("%5.1fin", f_vals[1]);
    printf("%5dft", int_vals[2]); printf("%5.1fin", f_vals[2]);
    printf("%5dft", int_vals[3]); printf("%5.1fin \n", f_vals[3]); 
}

/*
 * This is an overall print function which take pointer to root
 * and pointer to 
 */
void print_overall(competitor_nptr root_ptr, competition_nptr holder)
{   
    
    printf("Competition: %s  Date: %s", holder->competition_name, holder->competition_date);
    strtok(holder->competition_name, "\n");
    printf("NAME       competitor number      Cucumber        Carrot   Runner Bean  Total Length \n");
    printf("======================================================================================== \n");
                                                     
    traverser(root_ptr);
}

/* This function traverses the tree and on each traversal, 
 * it calls the print_competitors() function
 * which prints all their results in the format specified in the requirements
 */
void traverser(competitor_nptr root_ptr, competition_nptr holder)
{   
    
    if(root_ptr == NULL)return;
    
    traverser(root_ptr->left, holder);
    
    print_competitors(root_ptr);
    //printf("%s ££££ \n", root_ptr->competitor_name);
    
    traverser(root_ptr->right, holder);
}

