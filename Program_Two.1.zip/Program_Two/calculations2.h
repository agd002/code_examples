/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   calculations2.h
 * Author: Alvin
 *
 * Created on 09 December 2015, 04:35
 */


/* this function converts */
float inch_converter(int feet, float inches);

int get_int(float change);

float get_float(float change);