/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   competition.h
 * Author: Alvin
 */
#define MAX_READ_LEN 80
#define DATA_PATH "/aber/dap/HORT_237/"

typedef struct competitor_info {
    char competitor_name[MAX_READ_LEN];
    char competitor_address[MAX_READ_LEN];
    char competitor_contact_details[MAX_READ_LEN];
    int competitor_num;
    float competitor_cucumber;
    float competitor_carrot;
    float competitor_bean;
    
    struct competitor_info * left;
    struct competitor_info * right;
} competitor_node;

typedef competitor_node * competitor_nptr;

typedef struct competition {
    char competition_name[MAX_READ_LEN];
    char competition_date[MAX_READ_LEN];
    
} competition_node;

typedef competition_node * competition_nptr;
/* defining function prototypes here to be used in 
 * competition_process source files, other source files and main
 */

/* this function creates the competition tree and calls other functions
 * such as add_to_tree() and read_from_file() functions.
 */
competition_nptr create_event_details_struct(char * data_file);

competitor_nptr create_leader_board(char * data_file);

competitor_nptr read_create_tree(FILE * file_ptr);

void add_to_tree(competitor_nptr add_to, competitor_nptr to_add, float score_len_add_to, float score_len_to_add);

float total(competitor_nptr temp_ptr);
/* this function prints the competition tree taking 
 * param competitor_nptr.
 */

void print_overall(competitor_nptr root_ptr, competition_nptr holder);

void print_competitors(competitor_nptr root_ptr);