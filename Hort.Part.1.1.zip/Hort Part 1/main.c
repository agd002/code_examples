/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: Alvin
 *
 * Created on 03 December 2015, 16:23
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "competition.h"

/*
 * 
 */
int main(int argc, char** argv) {
    int exception = 0;
    do{
       char buffer2;
        int test;
        int * check;
        check = &test;
        /*reading in the input from the user of the file*/
        char buffer[MAX_READ_LEN];
        printf("Please enter the file name for the horticultural competition results: \n\n");
        scanf("%s", buffer);
        char data_path_str[MAX_READ_LEN];
        strcpy(data_path_str, DATA_PATH);
        strcat(data_path_str, buffer);
        competitor_nptr root_ptr;
        competition_nptr compet;
        /*checking if the file exists.
         * the check_file() function checks if the file exists.
         * if it does, the program continues, if it doesn't the program will end
         */
        check_file(data_path_str, check);
        /*
         * this creates a structure holding the details of the
         * competition to be accessed on printing
         */
        compet = create_event_details_struct(data_path_str);
        /*
         * this creates a structure holding the details of the
         * competitors to be accessed on printing
         */
        root_ptr = create_leader_board(data_path_str);
        /*
         * This function is an overall print function which 
         * calls the traverse function which calls a print
         * method taking in only one parameter, the pointer to the node.
         */
        print_overall(root_ptr, compet);
        exception++;
    }while(exception == 0);
    return (EXIT_SUCCESS);
}