/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   calculations.h
 * Author: Alvin
 *
 * Created on 09 December 2015, 04:35
 */

/* this function converts feet and inches to just inches */
float inch_converter(int feet, float inches);
/* this function gets the feet from the structure
 * where the length is stored in only inches */
int get_int(float change);
/* this function gets the inches from the structure
 * where the length is stored in only inches 
 * calculating the remainder to get the inches to a float
 */
float get_float(float change);